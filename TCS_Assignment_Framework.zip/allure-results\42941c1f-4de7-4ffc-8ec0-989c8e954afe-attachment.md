# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: searchItems.test.js >> Search items from CSV file
- Location: tests\searchItems.test.js:6:5

# Error details

```
TimeoutError: page.waitForSelector: Timeout 10000ms exceeded.
Call log:
  - waiting for locator('.card-title') to be visible

```

# Test source

```ts
  1  | import CommonMethods from '../common/CommonMethods.js';
  2  | 
  3  | export default class ProductPage {
  4  |   constructor(page) {
  5  |     this.page = page;
  6  |     this.common = new CommonMethods(page);
  7  |   }
  8  | 
  9  |   // Navigate to homepage
  10 |   async navigate() {
  11 |     await this.page.goto(process.env.E2E_BASE_URL);
  12 |     await this.page.waitForSelector('.navbar-brand');
  13 |   }
  14 | 
  15 |   // 🔧 New method added for search
  16 |   async searchItem(itemName) {
  17 |     // Demoblaze doesn’t have a real search box, so we simulate search by filtering product cards
  18 |     // This assumes items.csv/json contain product names like "Samsung galaxy s6"
> 19 |     await this.page.waitForSelector('.card-title', { timeout: 10000 });
     |                     ^ TimeoutError: page.waitForSelector: Timeout 10000ms exceeded.
  20 | 
  21 |     const productTitles = await this.page.locator('.card-title').allTextContents();
  22 |     const match = productTitles.find(title => title.toLowerCase().includes(itemName.toLowerCase()));
  23 | 
  24 |     if (!match) {
  25 |       throw new Error(`Item "${itemName}" not found on page`);
  26 |     }
  27 |   }
  28 | }
```