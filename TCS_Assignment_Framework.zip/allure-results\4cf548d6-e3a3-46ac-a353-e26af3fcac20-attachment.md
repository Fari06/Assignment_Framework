# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: multiUserLogin.test.js >> Multi User Login Tests >> Login with multiple users from CSV
- Location: tests\multiUserLogin.test.js:26:7

# Error details

```
Error: ENOENT: no such file or directory, open 'C:\Users\FARHEEN SIDDIQUA\TCS_Assignment_Framework\data\users.csv'
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - text:             
  - navigation [ref=e2]:
    - link "PRODUCT STORE" [ref=e3] [cursor=pointer]:
      - /url: index.html
      - img [ref=e4]
      - text: PRODUCT STORE
    - list [ref=e6]:
      - listitem [ref=e7]:
        - link "Home (current)" [ref=e8] [cursor=pointer]:
          - /url: index.html
          - text: Home
          - generic [ref=e9]: (current)
      - listitem [ref=e10]:
        - link "Contact" [ref=e11] [cursor=pointer]:
          - /url: "#"
      - listitem [ref=e12]:
        - link "About us" [ref=e13] [cursor=pointer]:
          - /url: "#"
      - listitem [ref=e14]:
        - link "Cart" [ref=e15] [cursor=pointer]:
          - /url: cart.html
      - listitem [ref=e16]:
        - link "Log in" [ref=e17] [cursor=pointer]:
          - /url: "#"
      - listitem
      - listitem
      - listitem [ref=e18]:
        - link "Sign up" [ref=e19] [cursor=pointer]:
          - /url: "#"
    - generic [ref=e21]:
      - list [ref=e22]:
        - listitem [ref=e23] [cursor=pointer]
        - listitem [ref=e24] [cursor=pointer]
        - listitem [ref=e25] [cursor=pointer]
      - img "First slide" [ref=e28]
      - button "Previous" [ref=e29] [cursor=pointer]:
        - generic [ref=e31]: Previous
      - button "Next" [ref=e32] [cursor=pointer]:
        - generic [ref=e34]: Next
  - generic [ref=e36]:
    - generic [ref=e38]:
      - link "CATEGORIES" [ref=e39] [cursor=pointer]:
        - /url: ""
      - link "Phones" [ref=e40] [cursor=pointer]:
        - /url: "#"
      - link "Laptops" [ref=e41] [cursor=pointer]:
        - /url: "#"
      - link "Monitors" [ref=e42] [cursor=pointer]:
        - /url: "#"
    - list [ref=e45]:
      - listitem [ref=e46]:
        - button "Previous" [ref=e47]
      - listitem [ref=e48]:
        - button "Next" [ref=e49] [cursor=pointer]
  - generic [ref=e51]:
    - generic [ref=e54]:
      - heading "About Us" [level=4] [ref=e55]
      - paragraph [ref=e56]: We believe performance needs to be validated at every stage of the software development cycle and our open source compatible, massively scalable platform makes that a reality.
    - generic [ref=e59]:
      - heading "Get in Touch" [level=4] [ref=e60]
      - paragraph [ref=e61]: "Address: 2390 El Camino Real"
      - paragraph [ref=e62]: "Phone: +440 123456"
      - paragraph [ref=e63]: "Email: demo@blazemeter.com"
    - heading "PRODUCT STORE" [level=4] [ref=e67]:
      - img [ref=e68]
      - text: PRODUCT STORE
  - contentinfo [ref=e69]:
    - paragraph [ref=e70]: Copyright © Product Store
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import LoginPage from '../page-objects/LoginPage.js';
  3  | import fs from 'fs';
  4  | 
  5  | // Utility to read CSV
  6  | function readCSV(filePath) {
> 7  |   const data = fs.readFileSync(filePath, 'utf-8');
     |                   ^ Error: ENOENT: no such file or directory, open 'C:\Users\FARHEEN SIDDIQUA\TCS_Assignment_Framework\data\users.csv'
  8  |   return data
  9  |     .trim()
  10 |     .split('\n')
  11 |     .slice(1) // skip header
  12 |     .map(line => {
  13 |       const [username, password] = line.split(',');
  14 |       return { username, password };
  15 |     });
  16 | }
  17 | 
  18 | // Utility to read JSON
  19 | function readJSON(filePath) {
  20 |   const data = fs.readFileSync(filePath, 'utf-8');
  21 |   return JSON.parse(data);
  22 | }
  23 | 
  24 | test.describe('Multi User Login Tests', () => {
  25 | 
  26 |   test('Login with multiple users from CSV', async ({ page }) => {
  27 |     const login = new LoginPage(page);
  28 |     await login.navigate();   // FIX: ensure homepage loads before clicking #login2
  29 | 
  30 |     const users = readCSV('data/users.csv');
  31 |     for (const user of users) {
  32 |       await login.login(user.username, user.password);
  33 |       await expect(page.locator('#logout2')).toBeVisible({ timeout: 10000 });
  34 |       await page.click('#logout2');
  35 |     }
  36 |   });
  37 | 
  38 |   test('Login with multiple users from JSON', async ({ page }) => {
  39 |     const login = new LoginPage(page);
  40 |     await login.navigate();   // FIX: ensure homepage loads before clicking #login2
  41 | 
  42 |     const users = readJSON('data/users.json');
  43 |     for (const user of users) {
  44 |       await login.login(user.username, user.password);
  45 |       await expect(page.locator('#logout2')).toBeVisible({ timeout: 10000 });
  46 |       await page.click('#logout2');
  47 |     }
  48 |   });
  49 | 
  50 | });
```