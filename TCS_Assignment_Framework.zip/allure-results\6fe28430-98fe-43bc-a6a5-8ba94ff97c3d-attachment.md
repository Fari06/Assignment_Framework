# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: searchItems.test.js >> Search Items Test >> Search items from CSV file
- Location: tests\searchItems.test.js:19:7

# Error details

```
TypeError: Cannot read properties of undefined (reading 'readCsvFile')
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import ProductPage from '../page-objects/ProductPage.js';
  3  | import ExcelUtil from '../utils/excelUtil.js';
  4  | import CsvUtil from '../utils/csvUtil.js';
  5  | import JsonUtil from '../utils/jsonUtil.js';
  6  | 
  7  | test.describe('Search Items Test', () => {
  8  | 
  9  |   test('Search items from Excel file', async ({ page }) => {
  10 |     const productPage = new ProductPage(page);
  11 |     const items = ExcelUtil.readExcelFile('./data-files/items.xlsx');
  12 | 
  13 |     for (const item of items) {
  14 |       await productPage.searchItem(item.name);
  15 |       await expect(page.locator('.card-title')).toContainText(item.name);
  16 |     }
  17 |   });
  18 | 
  19 |   test('Search items from CSV file', async ({ page }) => {
  20 |     const productPage = new ProductPage(page);
> 21 |     const items = CsvUtil.readCsvFile('./data-files/items.csv');
     |                           ^ TypeError: Cannot read properties of undefined (reading 'readCsvFile')
  22 | 
  23 |     for (const item of items) {
  24 |       await productPage.searchItem(item.name);
  25 |       await expect(page.locator('.card-title')).toContainText(item.name);
  26 |     }
  27 |   });
  28 | 
  29 |   test('Search items from JSON file', async ({ page }) => {
  30 |     const productPage = new ProductPage(page);
  31 |     const items = JsonUtil.readJsonFile('./data-files/items.json');
  32 | 
  33 |     for (const item of items) {
  34 |       await productPage.searchItem(item.name);
  35 |       await expect(page.locator('.card-title')).toContainText(item.name);
  36 |     }
  37 |   });
  38 | 
  39 | });
```